global.creator = "@AmamgXd"
global.token = "TOKEN BOT"
global.chatid = "USER ID"
global.watermark = "© AmangXd"
