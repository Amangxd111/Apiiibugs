global.creator = "@AmamgXd"
global.token = "7233620808:AAE9gFZbRAze6zU3I_KOG4w38cNpONUj-v8"
global.chatid = "6897791527"
global.watermark = "© AmangXd"
