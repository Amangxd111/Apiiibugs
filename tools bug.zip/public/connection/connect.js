exports.konek = async ({ client, update, clientstart, DisconnectReason, Boom }) => {
  const { connection, lastDisconnect } = update;

  if (connection === 'close') {
    let reason = new Boom(lastDisconnect?.error)?.output.statusCode;

    switch (reason) {
      case DisconnectReason.badSession:
        console.log(`❌ Bad session file. Hapus session dan scan ulang.`);
        process.exit(1);
        break;

      case DisconnectReason.connectionClosed:
      case DisconnectReason.connectionLost:
      case DisconnectReason.timedOut:
      case DisconnectReason.restartRequired:
        console.log(`🔄 Koneksi terputus (${reason}), mencoba ulang...`);
        clientstart();
        break;

      case DisconnectReason.connectionReplaced:
        console.log(`⚠️ Session digantikan, keluar...`);
        process.exit(1);
        break;

      case DisconnectReason.loggedOut:
        console.log(`🚫 Akun logout! Scan ulang WA.`);
        process.exit(1);
        break;

      default:
        console.log(`❓ Alasan disconnect tidak dikenal (${reason}), restart total...`);
        process.exit(1);
    }

  } else if (connection === "open") {
    console.log("✅ Bot berhasil terhubung! Menunggu 3 detik sebelum restart otomatis...");

    setTimeout(() => {
      try {
        const nomor = client.user.id.split(':')[0];
        console.log(`
===================================================
✅ Bot terhubung ke WhatsApp!
🔁 Akan restart untuk koneksi ulang...
🔗 Nomor: ${nomor}
===================================================
Owner: @AmangXd1
===================================================
        `);
      } catch {
        console.log("✅ Bot konek, tapi gagal ambil nomor.");
      }

      process.exit(0);
    }, 3000);
  }
};