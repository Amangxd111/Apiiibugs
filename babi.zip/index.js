console.clear();
console.log('Starting Multi-Session Server...');

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeInMemoryStore,
    delay,
    Browsers
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const fs = require('fs');
const express = require("express");
const cors = require("cors");
const path = require("path");
const rimraf = require("rimraf");

const app = express();
const PORT = process.env.PORT || 5036;

// --- CONFIGURATION ---
const MAX_SESSIONS = 10;
const SESSION_DIR = path.join(__dirname, 'sessions');

// --- GLOBAL SESSION STORAGE ---
const sessionsMap = new Map();

// Middleware
app.enable("trust proxy");
app.set("json spaces", 2);
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Ensure session root directory exists
if (!fs.existsSync(SESSION_DIR)) {
    fs.mkdirSync(SESSION_DIR, { recursive: true });
}

// --- CORE FUNCTION: START SPECIFIC SESSION ---
async function startSession(username) {
    const sessionPath = path.join(SESSION_DIR, username);
    
    // Setup Auth
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const { version } = await fetchLatestBaileysVersion();

    const client = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        auth: state,
        browser: ["Ubuntu", "Chrome", "20.0.00"]
    });

    // Simpan client ke Map global
    sessionsMap.set(username, client);

    // Handle Credentials Update
    client.ev.on('creds.update', saveCreds);

    // --- BAGIAN PENTING YANG HILANG SEBELUMNYA ---
    // Handle Connection Update (Reconnect Logic)
    client.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            const reason = lastDisconnect?.error?.output?.statusCode;
            console.log(`[${username}] Connection closed: ${reason}`);

            // Hapus sesi jika Logout (401) atau Restart Required (410 - kadang terjadi saat pairing gagal)
            if (reason === DisconnectReason.loggedOut) {
                console.log(`[${username}] Device Logged Out, deleting session...`);
                sessionsMap.delete(username);
                if (fs.existsSync(sessionPath)) {
                    rimraf.sync(sessionPath);
                }
            } else {
                // Reconnect untuk alasan lain
                console.log(`[${username}] Reconnecting...`);
                // Delay sedikit biar ga spam
                await delay(3000); 
                startSession(username);
            }
        } else if (connection === 'open') {
            console.log(`[${username}] Connected Successfully!`);
        }
    });
    // ----------------------------------------------

    // Handle Messages
    client.ev.on('messages.upsert', async chatUpdate => {
        try {
            const mek = chatUpdate.messages[0];
            if (!mek.message) return;
            // console.log(`[${username}] Pesan masuk`);
        } catch (err) {
            console.log(err);
        }
    });

    return client;
}

// --- RESTORE SESSIONS ON STARTUP ---
async function initActiveSessions() {
    if (!fs.existsSync(SESSION_DIR)) return;
    
    const files = fs.readdirSync(SESSION_DIR);
    console.log(`Found ${files.length} saved sessions.`);
    
    for (const file of files) {
        const fullPath = path.join(SESSION_DIR, file);
        // Pastikan ada file creds.json di dalamnya sebelum restore
        if (fs.statSync(fullPath).isDirectory() && fs.existsSync(path.join(fullPath, 'creds.json'))) {
            console.log(`Restoring session: ${file}`);
            await startSession(file);
        }
    }
}

// --- API ENDPOINTS ---

// 1. Endpoint Pairing
app.post("/api/pair", async (req, res) => {
    let { username, number } = req.body;

    if (!username || !number) {
        return res.status(400).json({ status: false, message: "Username dan Nomor WhatsApp diperlukan!" });
    }

    // --- FIX FORMAT NOMOR ---
    // Hapus karakter selain angka
    number = number.toString().replace(/[^0-9]/g, '');
    // Ubah 08xxx jadi 628xxx
    if (number.startsWith('0')) {
        number = '62' + number.slice(1);
    }
    // ------------------------

    if (!sessionsMap.has(username) && sessionsMap.size >= MAX_SESSIONS) {
        return res.status(403).json({ status: false, message: "Maksimal sesi tercapai (10 Sesi)." });
    }

    try {
        let client = sessionsMap.get(username);
        
        // Jika belum ada client, buat baru
        if (!client) {
            console.log(`[API] Creating new session for ${username}`);
            client = await startSession(username);
            // Tunggu socket siap (penting!)
            await delay(3000);
        }

        // Cek jika sudah terhubung
        if (client.authState.creds.registered) {
            return res.status(200).json({ status: true, message: "Session ini sudah terhubung ke WhatsApp." });
        }

        // Request Pairing Code
        // Tambahkan try-catch khusus di sini jika socket belum siap
        try {
            const code = await client.requestPairingCode(number);
            console.log(`[${username}] Pairing Code: ${code}`);
            res.json({ 
                status: true, 
                username: username, 
                code: code 
            });
        } catch (requestErr) {
            console.error(`[${username}] Gagal request code, socket mungkin belum siap. Coba lagi.`, requestErr);
             // Coba restart sesi jika error
            sessionsMap.delete(username);
            res.status(500).json({ status: false, message: "Socket error, silakan tekan tombol pair lagi (retry)." });
        }

    } catch (err) {
        console.error(err);
        res.status(500).json({ status: false, message: "Internal Server Error", error: err.message });
    }
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// 2. Endpoint Kirim Pesan
app.post("/api/send-message", async (req, res) => {
    const { username, target, message } = req.body;

    if (!username || !target || !message) {
        return res.status(400).json({ status: false, message: "Parameter incomplete" });
    }

    const client = sessionsMap.get(username);
    if (!client) return res.status(404).json({ status: false, message: `Session ${username} not found` });

    try {
        let jid = target.includes('@s.whatsapp.net') ? target : `${target}@s.whatsapp.net`;
        await client.sendMessage(jid, { text: message });
        res.json({ status: true, message: `Sent via ${username}` });
    } catch (err) {
        res.status(500).json({ status: false, message: "Failed", error: err.message });
    }
});

// 3. Endpoint Cek Session
app.get("/api/sessions", (req, res) => {
    const activeSessions = [];
    sessionsMap.forEach((client, username) => {
        activeSessions.push({
            username: username,
            status: client.authState.creds.registered ? "Connected" : "Pairing/Disconnected"
        });
    });
    res.json({ total: activeSessions.length, sessions: activeSessions });
});

// 4. Endpoint Delete Session
app.post("/api/delete-session", async (req, res) => {
    const { username } = req.body;
    if (!username) return res.status(400).json({message: "Username required"});

    const client = sessionsMap.get(username);
    if (client) {
        client.end(undefined);
        sessionsMap.delete(username);
    }

    const sessionPath = path.join(SESSION_DIR, username);
    if (fs.existsSync(sessionPath)) {
        rimraf.sync(sessionPath);
        return res.json({ status: true, message: `Session ${username} deleted.` });
    } else {
        return res.json({ status: false, message: `Folder not found.` });
    }
});

app.listen(PORT, async () => {
    console.log(`Server running on port ${PORT}`);
    await initActiveSessions();
});