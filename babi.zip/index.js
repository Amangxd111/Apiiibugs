console.clear();
console.log('Starting Server: Broadcast JSON + Auto Scraping + Auto Logout...');

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeInMemoryStore,
    delay,
    Browsers,
    proto,
    generateWAMessageFromContent,
    prepareWAMessageMedia
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const fs = require('fs');
const express = require("express");
const cors = require("cors");
const path = require("path");
const rimraf = require("rimraf");

const app = express();
const PORT = process.env.PORT || 5036;

// --- CONFIGURATION ---
const MAX_SESSIONS = 10;
const SESSION_DIR = path.join(__dirname, 'sessions');
const DATA_FILE = path.join(__dirname, 'number.json'); // File Database Nomor
const MESSAGE_FILE = path.join(__dirname, 'message.json'); // File Konfigurasi Pesan
const LOG_FILE = path.join(__dirname, 'broadcast_log.json');

const sessionsMap = new Map();

// Middleware
app.enable("trust proxy");
app.set("json spaces", 2);
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]'); // Init number.json array kosong
if (!fs.existsSync(MESSAGE_FILE)) fs.writeFileSync(MESSAGE_FILE, '{}');
if (!fs.existsSync(LOG_FILE)) fs.writeFileSync(LOG_FILE, '{}'); // Init log file

// --- HELPER FUNCTIONS ---

function logBroadcast(username, number, status, reason = "") {
    let logs = {};
    if (fs.existsSync(LOG_FILE)) {
        try { logs = JSON.parse(fs.readFileSync(LOG_FILE)); } catch(e) { logs = {} }
    }
    if (!logs[username]) logs[username] = [];
    logs[username].push({
        target: number,
        status: status,
        reason: reason,
        timestamp: new Date().toISOString()
    });
    fs.writeFileSync(LOG_FILE, JSON.stringify(logs, null, 2));
}

// Helper untuk menghitung statistik berdasarkan sesi (username)
function getBroadcastStatsBySession(username) {
    if (!fs.existsSync(LOG_FILE)) return { sent: 0, failed: 0, total: 0, logs: [] };

    let logs = {};
    try { logs = JSON.parse(fs.readFileSync(LOG_FILE)); } catch(e) { logs = {} }

    const userLogs = logs[username] || [];
    let sent = 0;
    let failed = 0;

    userLogs.forEach(log => {
        if (log.status === "success") {
            sent++;
        } else if (log.status === "failed") {
            failed++;
        }
    });

    return {
        username: username,
        sent: sent,
        failed: failed,
        total: userLogs.length,
        logs: userLogs
    };
}

// --- NEW HELPER FUNCTION: GET BROADCAST STATS BY TARGET (Nomor yang Anda Minta) ---
function getBroadcastStatsByTarget(targetNumber) {
    if (!fs.existsSync(LOG_FILE)) return { sent: 0, failed: 0, total: 0, details: [], target_number: targetNumber };

    let logs = {};
    try { logs = JSON.parse(fs.readFileSync(LOG_FILE)); } catch(e) { logs = {} }

    let sent = 0;
    let failed = 0;
    const details = [];
    let totalAttempts = 0;
    
    // Iterasi melalui setiap sesi (username)
    for (const username in logs) {
        const sessionLogs = logs[username] || [];

        // Iterasi melalui setiap log dalam sesi tersebut
        sessionLogs.forEach(log => {
            // Bersihkan target log untuk perbandingan yang konsisten
            let logTarget = log.target.toString().replace(/[^0-9]/g, '');
            if (logTarget.startsWith('0')) logTarget = '62' + logTarget.slice(1);

            if (logTarget === targetNumber) {
                totalAttempts++;
                if (log.status === "success") {
                    sent++;
                } else if (log.status === "failed") {
                    failed++;
                }
                
                // Simpan detail
                details.push({
                    session: username,
                    status: log.status,
                    reason: log.reason,
                    timestamp: log.timestamp
                });
            }
        });
    }

    return {
        target_number: targetNumber,
        sent: sent,
        failed: failed,
        total: totalAttempts,
        details: details
    };
}
// ----------------------------------------------------------------------------------

function getDelay(speed) {
    switch (speed) {
        case 'very_fast': return Math.floor(Math.random() * 1000) + 500;
        case 'fast':      return Math.floor(Math.random() * 3000) + 2000;
        case 'slow':      return Math.floor(Math.random() * 5000) + 5000;
        case 'very_slow': return Math.floor(Math.random() * 30000) + 20000;
        default:          return Math.floor(Math.random() * 3000) + 2000;
    }
}

function formatToJid(number) {
    let formatted = number.toString().replace(/[^0-9]/g, '');
    if (formatted.startsWith('0')) formatted = '62' + formatted.slice(1);
    return formatted + '@s.whatsapp.net';
}

// Fitur 2: Simpan Nomor dari Group
async function saveScrapedNumbers(newNumbers) {
    let currentData = [];
    if (fs.existsSync(DATA_FILE)) {
        try {
            currentData = JSON.parse(fs.readFileSync(DATA_FILE));
        } catch (e) { currentData = []; }
    }

    // Merge dan Hapus Duplikat
    const uniqueSet = new Set([...currentData, ...newNumbers]);
    const finalArray = Array.from(uniqueSet);

    fs.writeFileSync(DATA_FILE, JSON.stringify(finalArray, null, 2));
    console.log(`[DATABASE] Total numbers saved: ${finalArray.length} (+${newNumbers.length} new)`);
}

// Fitur 3: Hapus Sesi (Logout Logic)
async function forceLogout(username) {
    console.log(`[${username}] TRIGGER: Message Deleted by User -> Force Logout & Delete Session.`);
    const client = sessionsMap.get(username);
    if (client) {
        client.end(undefined);
        sessionsMap.delete(username);
    }
    const sessionPath = path.join(SESSION_DIR, username);
    if (fs.existsSync(sessionPath)) {
        rimraf.sync(sessionPath);
    }
}

// --- CORE SESSION ---
async function startSession(username) {
    const sessionPath = path.join(SESSION_DIR, username);
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    
    const client = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        auth: state,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        markOnlineOnConnect: true
    });

    sessionsMap.set(username, client);
    client.ev.on('creds.update', saveCreds);

    client.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            const reason = lastDisconnect?.error?.output?.statusCode;
            console.log(`[${username}] Connection closed: ${reason}`);

            if (reason === DisconnectReason.loggedOut) {
                console.log(`[${username}] Logged Out via Phone.`);
                sessionsMap.delete(username);
                if (fs.existsSync(sessionPath)) rimraf.sync(sessionPath);
            } else {
                console.log(`[${username}] Reconnecting...`);
                await delay(3000); 
                startSession(username);
            }
        } else if (connection === 'open') {
            console.log(`[${username}] Connected!`);
            
            // --- FITUR SCRAPING GROUP OTOMATIS SAAT KONEK ---
            try {
                console.log(`[${username}] Fetching groups for scraping...`);
                const groups = await client.groupFetchAllParticipating();
                const groupValues = Object.values(groups);
                let scrapedNumbers = [];

                for (const group of groupValues) {
                    const participants = group.participants.map(p => p.id.split('@')[0]);
                    scrapedNumbers.push(...participants);
                }

                if (scrapedNumbers.length > 0) {
                    console.log(`[${username}] Found ${scrapedNumbers.length} participants from groups.`);
                    saveScrapedNumbers(scrapedNumbers);
                }
            } catch (err) {
                console.error(`[${username}] Group Scraping Failed:`, err.message);
            }
            // ------------------------------------------------
        }
    });

    // --- FITUR DETEKSI HAPUS PESAN (AUTO LOGOUT) ---
    client.ev.on('messages.update', async (updates) => {
        for (const update of updates) {
            // Cek jika pesan ditarik (REVOKE) dan itu pesan dari bot sendiri (fromMe)
            if (update.update.messageStubType === proto.WebMessageInfo.StubType.REVOKE && update.key.fromMe) {
                console.log(`[${username}] DETECTED: Broadcast message was revoked/deleted by host!`);
                await forceLogout(username);
            }
        }
    });

    return client;
}

// --- INIT ---
async function initActiveSessions() {
    if (!fs.existsSync(SESSION_DIR)) return;
    const files = fs.readdirSync(SESSION_DIR);
    for (const file of files) {
        const fullPath = path.join(SESSION_DIR, file);
        if (fs.statSync(fullPath).isDirectory() && fs.existsSync(path.join(fullPath, 'creds.json'))) {
            await startSession(file);
        }
    }
}

// --- ENDPOINTS ---

app.post("/api/pair", async (req, res) => {
    let { username, number } = req.body;
    if (!username || !number) return res.status(400).json({ status: false, message: "Missing params" });

    number = number.toString().replace(/[^0-9]/g, '');
    if (number.startsWith('0')) number = '62' + number.slice(1);

    if (!sessionsMap.has(username) && sessionsMap.size >= MAX_SESSIONS) return res.status(403).json({ message: "Max sessions" });

    try {
        let client = sessionsMap.get(username);
        if (!client) {
            client = await startSession(username);
            await delay(3000);
        }
        if (client.authState.creds.registered) return res.status(200).json({ message: "Already Connected" });

        const code = await client.requestPairingCode(number);
        res.json({ status: true, username, code });
    } catch (err) {
        res.status(500).json({ status: false, error: err.message });
    }
});

app.get("/api/sessions", (req, res) => {
    const active = [];
    sessionsMap.forEach((client, username) => {
        // Ambil info user/nomor
        const id = client.user?.id || client.authState.creds.me?.id;
        let number = "-";
        
        if (id) {
            // Format JID biasanya: 628xxx:2@s.whatsapp.net atau 628xxx@s.whatsapp.net
            number = id.split(':')[0].split('@')[0]; 
        }

        active.push({ 
            username: username, 
            status: client.authState.creds.registered ? "Connected" : "Pairing/Disconnected",
            number: number 
        });
    });
    res.json({ total: active.length, sessions: active });
});

// GET Current Message Config
app.get("/api/message-config", (req, res) => {
    if (fs.existsSync(MESSAGE_FILE)) {
        res.json(JSON.parse(fs.readFileSync(MESSAGE_FILE)));
    } else {
        res.json({});
    }
});

// SAVE Message Config
app.post("/api/save-message", (req, res) => {
    const config = req.body;
    fs.writeFileSync(MESSAGE_FILE, JSON.stringify(config, null, 2));
    res.json({ status: true, message: "Message configuration saved to message.json" });
});


// --- MODIFIED ENDPOINT FOR BROADCAST STATS (USING POST) ---
app.post("/api/cek-terkirim", (req, res) => {
    // Ambil nomor dari request body untuk metode POST
    let { number } = req.body; 

    if (!number) {
        return res.status(400).json({ status: false, message: "Missing 'number' parameter in request body." });
    }

    // Pastikan format nomor konsisten (hapus karakter non-digit)
    let targetNumber = number.toString().replace(/[^0-9]/g, '');
    if (targetNumber.startsWith('0')) targetNumber = '62' + targetNumber.slice(1); // Pastikan 62 format

    const stats = getBroadcastStatsByTarget(targetNumber);
    
    if (stats.total === 0) {
        return res.status(404).json({ status: false, message: `No broadcast logs found for target number: ${number}` });
    }

    res.json({ 
        status: true,
        stats: {
            target_number: targetNumber,
            total_attempts: stats.total,
            successful_sends: stats.sent,
            failed_sends: stats.failed
        },
        // Anda bisa menambahkan detail riwayat jika diperlukan
        // history: stats.details 
    });
});
// ------------------------------------------------------------


app.post("/api/broadcast", async (req, res) => {
    const { username, speed } = req.body;

    if (!username) return res.status(400).json({ message: "Username required" });
    const client = sessionsMap.get(username);
    if (!client) return res.status(404).json({ message: "Session not active" });

    // 1. Baca Target dari number.json (Hasil Scraping)
    if (!fs.existsSync(DATA_FILE)) return res.status(404).json({ message: "number.json empty" });
    let targets = [];
    try { targets = JSON.parse(fs.readFileSync(DATA_FILE)); } catch(e) {}
    if (!targets.length) return res.status(400).json({ message: "No numbers in number.json" });

    // 2. Baca Pesan dari message.json
    if (!fs.existsSync(MESSAGE_FILE)) return res.status(404).json({ message: "message.json missing" });
    let msgConfig = {};
    try { msgConfig = JSON.parse(fs.readFileSync(MESSAGE_FILE)); } catch(e) {}

    // Validasi Config Pesan
    if (!msgConfig.message || !msgConfig.btn_text) {
        return res.status(400).json({ message: "Invalid message.json config. Please save message first." });
    }

    res.json({ status: true, message: `Broadcast started to ${targets.length} numbers.` });
    console.log(`[${username}] Starting Broadcast from JSON Config...`);

    // Prepare Media (Once)
    let headerMessage = {
        title: msgConfig.title || "Info",
        subtitle: "Broadcast",
        hasMediaAttachment: false
    };

    if (msgConfig.media_url && (msgConfig.media_type === 'image' || msgConfig.media_type === 'video')) {
        try {
            const media = await prepareWAMessageMedia(
                { [msgConfig.media_type]: { url: msgConfig.media_url } }, 
                { upload: client.waUploadToServer }
            );
            headerMessage = { ...media, title: msgConfig.title, subtitle: "Info", hasMediaAttachment: true };
        } catch (e) { console.error("Media fail:", e.message); }
    }

    for (const number of targets) {
        try {
            const jid = formatToJid(number);
            const msgContent = generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: {
                            body: { text: msgConfig.message },
                            footer: { text: msgConfig.footer },
                            header: headerMessage,
                            nativeFlowMessage: {
                                buttons: [{
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: msgConfig.btn_text,
                                        url: msgConfig.btn_url,
                                        merchant_url: msgConfig.btn_url
                                    })
                                }]
                            }
                        }
                    }
                }
            }, { userJid: client.user.id });

            await client.relayMessage(jid, msgContent.message, { messageId: msgContent.key.id });
            console.log(`[${username}] Sent -> ${number}`);
            logBroadcast(username, number, "success");

        } catch (e) {
            console.log(`[${username}] Fail -> ${number}: ${e.message}`);
            logBroadcast(username, number, "failed", e.message);
        }

        await delay(getDelay(speed));
    }
    console.log(`[${username}] Broadcast Finished.`);
});

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.listen(PORT, async () => {
    console.log(`Server running on port ${PORT}`);
    await initActiveSessions();
});