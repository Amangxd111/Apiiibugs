console.clear();
console.log('Starting Multi-Session Server with Advanced Broadcast...');

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeInMemoryStore,
    delay,
    Browsers,
    proto,
    generateWAMessageFromContent,
    prepareWAMessageMedia // WAJIB: Untuk handle upload gambar/video
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const fs = require('fs');
const express = require("express");
const cors = require("cors");
const path = require("path");
const rimraf = require("rimraf");

const app = express();
const PORT = process.env.PORT || 5036;

// --- CONFIGURATION ---
const MAX_SESSIONS = 10;
const SESSION_DIR = path.join(__dirname, 'sessions');
const DATA_FILE = path.join(__dirname, 'number.json'); 
const LOG_FILE = path.join(__dirname, 'broadcast_log.json'); // File Log Baru

// --- GLOBAL SESSION STORAGE ---
const sessionsMap = new Map();

// Middleware
app.enable("trust proxy");
app.set("json spaces", 2);
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Ensure session root directory exists
if (!fs.existsSync(SESSION_DIR)) {
    fs.mkdirSync(SESSION_DIR, { recursive: true });
}

// --- HELPER: LOGGER BROADCAST ---
function logBroadcast(username, number, status, reason = "") {
    let logs = {};
    // Baca file log jika ada
    if (fs.existsSync(LOG_FILE)) {
        try {
            logs = JSON.parse(fs.readFileSync(LOG_FILE));
        } catch(e) { logs = {} }
    }

    // Buat array untuk username jika belum ada
    if (!logs[username]) logs[username] = [];

    // Push log baru
    logs[username].push({
        target: number,
        status: status, // 'success' atau 'failed'
        reason: reason,
        timestamp: new Date().toISOString()
    });

    // Simpan kembali
    fs.writeFileSync(LOG_FILE, JSON.stringify(logs, null, 2));
}

// --- HELPER: DELAY STRATEGY ---
function getDelay(speed) {
    switch (speed) {
        case 'very_fast': 
            return Math.floor(Math.random() * 1000) + 500;   // 0.5 - 1.5 detik
        case 'fast':      
            return Math.floor(Math.random() * 3000) + 2000;  // 2 - 5 detik (Default)
        case 'slow':      
            return Math.floor(Math.random() * 5000) + 5000;  // 5 - 10 detik
        case 'very_slow': 
            return Math.floor(Math.random() * 10000) + 10000;// 10 - 20 detik
        default:          
            return Math.floor(Math.random() * 3000) + 2000;
    }
}

// --- CORE FUNCTION: START SPECIFIC SESSION ---
async function startSession(username) {
    const sessionPath = path.join(SESSION_DIR, username);
    
    // Setup Auth
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const { version } = await fetchLatestBaileysVersion();

    const client = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        auth: state,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        markOnlineOnConnect: true
    });

    sessionsMap.set(username, client);
    client.ev.on('creds.update', saveCreds);

    client.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            const reason = lastDisconnect?.error?.output?.statusCode;
            console.log(`[${username}] Connection closed: ${reason}`);

            if (reason === DisconnectReason.loggedOut) {
                console.log(`[${username}] Device Logged Out, deleting session...`);
                sessionsMap.delete(username);
                if (fs.existsSync(sessionPath)) {
                    rimraf.sync(sessionPath);
                }
            } else {
                console.log(`[${username}] Reconnecting...`);
                await delay(3000); 
                startSession(username);
            }
        } else if (connection === 'open') {
            console.log(`[${username}] Ready!`);
        }
    });

    return client;
}

// --- RESTORE SESSIONS ON STARTUP ---
async function initActiveSessions() {
    if (!fs.existsSync(SESSION_DIR)) return;
    const files = fs.readdirSync(SESSION_DIR);
    console.log(`Found ${files.length} saved sessions.`);
    for (const file of files) {
        const fullPath = path.join(SESSION_DIR, file);
        if (fs.statSync(fullPath).isDirectory() && fs.existsSync(path.join(fullPath, 'creds.json'))) {
            console.log(`Restoring session: ${file}`);
            await startSession(file);
        }
    }
}

// --- HELPER: FORMAT NUMBER ---
function formatToJid(number) {
    let formatted = number.toString().replace(/[^0-9]/g, '');
    if (formatted.startsWith('0')) {
        formatted = '62' + formatted.slice(1);
    }
    return formatted + '@s.whatsapp.net';
}

// --- API ENDPOINTS ---

app.post("/api/pair", async (req, res) => {
    let { username, number } = req.body;
    if (!username || !number) return res.status(400).json({ status: false, message: "Username & Number required" });

    number = number.toString().replace(/[^0-9]/g, '');
    if (number.startsWith('0')) number = '62' + number.slice(1);

    if (!sessionsMap.has(username) && sessionsMap.size >= MAX_SESSIONS) {
        return res.status(403).json({ status: false, message: "Max sessions reached." });
    }

    try {
        let client = sessionsMap.get(username);
        if (!client) {
            console.log(`[API] Creating new session for ${username}`);
            client = await startSession(username);
            await delay(3000);
        }

        if (client.authState.creds.registered) {
            return res.status(200).json({ status: true, message: "Already registered." });
        }

        const code = await client.requestPairingCode(number);
        res.json({ status: true, username, code });
    } catch (err) {
        res.status(500).json({ status: false, message: "Internal Error", error: err.message });
    }
});

app.get("/api/sessions", (req, res) => {
    const activeSessions = [];
    sessionsMap.forEach((client, username) => {
        activeSessions.push({
            username: username,
            status: client.authState.creds.registered ? "Connected" : "Pairing/Disconnected"
        });
    });
    res.json({ total: activeSessions.length, sessions: activeSessions });
});

// --- API BROADCAST DINAMIS ---
app.post("/api/broadcast", async (req, res) => {
    // Ambil semua parameter dari body request (UI/Postman)
    const { 
        username, 
        message,        // Isi Pesan Utama
        title,          // Header Title (Bold)
        footer,         // Footer Text
        btn_text,       // Teks Tombol
        btn_url,        // URL Tombol
        media_url,      // URL Gambar/Video (Opsional)
        media_type,     // 'image' atau 'video'
        speed           // 'very_slow', 'slow', 'fast', 'very_fast'
    } = req.body; 

    // Validasi Basic
    if (!username || !message || !btn_text || !btn_url) {
        return res.status(400).json({ status: false, message: "Incomplete params (username, message, btn_text, btn_url required)" });
    }

    const client = sessionsMap.get(username);
    if (!client) return res.status(404).json({ status: false, message: "Session not found / not active" });

    if (!fs.existsSync(DATA_FILE)) {
        return res.status(404).json({ status: false, message: "data.json not found" });
    }

    // Baca Target
    let targets = [];
    try {
        targets = JSON.parse(fs.readFileSync(DATA_FILE));
    } catch (e) {
        return res.status(400).json({ status: false, message: "Invalid JSON in data.json" });
    }

    if (!targets.length) return res.status(400).json({ message: "No numbers in data.json" });

    // Kirim Response duluan agar client tidak timeout
    res.json({ 
        status: true, 
        message: `Broadcast started to ${targets.length} numbers using speed: ${speed || 'fast'}. Check 'broadcast_log.json' for details.` 
    });

    console.log(`[${username}] Starting Dynamic Broadcast (${speed || 'fast'})...`);

    // --- PERSIAPAN MEDIA (JIKA ADA) ---
    let headerMessage = {
        title: title || "Broadcast Info",
        subtitle: "Info",
        hasMediaAttachment: false
    };

    // Jika user mengirim url media
    if (media_url && (media_type === 'image' || media_type === 'video')) {
        try {
            console.log(`[${username}] Downloading media from URL...`);
            // Baileys perlu download media dulu jadi buffer/stream
            const media = await prepareWAMessageMedia(
                { [media_type]: { url: media_url } }, 
                { upload: client.waUploadToServer }
            );
            
            // Override header dengan media
            headerMessage = { 
                ...media, 
                title: title || "Broadcast Info", 
                subtitle: "Info", 
                hasMediaAttachment: true 
            };
        } catch (e) {
            console.error(`[${username}] Media download failed, sending text only. Error:`, e.message);
        }
    }

    // --- LOOP BROADCAST ---
    for (const number of targets) {
        try {
            const jid = formatToJid(number);
            
            // Susun Pesan Native Flow
            const msgContent = generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: {
                            body: { text: message },
                            footer: { text: footer || "Broadcast System" },
                            header: headerMessage, // Header dinamis
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "cta_url",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: btn_text,
                                            url: btn_url,
                                            merchant_url: btn_url
                                        })
                                    }
                                ]
                            }
                        }
                    }
                }
            }, { userJid: client.user.id });

            // Kirim
            await client.relayMessage(jid, msgContent.message, { messageId: msgContent.key.id });
            
            console.log(`[${username}] Success -> ${number}`);
            
            // Catat Log Sukses
            logBroadcast(username, number, "success");

        } catch (e) {
            console.log(`[${username}] Failed -> ${number}: ${e.message}`);
            
            // Catat Log Gagal
            logBroadcast(username, number, "failed", e.message);
        }

        // Delay sesuai Speed yang dipilih
        const delayTime = getDelay(speed);
        await delay(delayTime);
    }

    console.log(`[${username}] Broadcast Finished.`);
});

app.post("/api/delete-session", async (req, res) => {
    const { username } = req.body;
    const client = sessionsMap.get(username);
    if (client) {
        client.end(undefined);
        sessionsMap.delete(username);
    }
    const sessionPath = path.join(SESSION_DIR, username);
    if (fs.existsSync(sessionPath)) {
        rimraf.sync(sessionPath);
        return res.json({ status: true, message: `Session deleted.` });
    }
    res.json({ status: false, message: `Folder not found.` });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, async () => {
    console.log(`Server running on port ${PORT}`);
    await initActiveSessions();
});